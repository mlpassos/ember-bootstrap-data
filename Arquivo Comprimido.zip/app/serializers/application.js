import DS from 'ember-data';

export default DS.RESTSerializer.extend({
	normalizeResponse(store, primaryModelClass, payload, id, requestType) {
		// let tlk;
		switch(requestType) {
			case 'query':
				console.log(payload);
				// tlk = Ember.Inflector.inflector.pluralize(primaryModelClass.modelName);
				// console.log('query', payload['posts']);
				// payload = payload.map((rawPost) => {
				// 	return rawPost;
				// });
				break;
			case 'findAll':
				console.log('findAll', payload['posts']);
			default:
				// debugger;
		}
		return this._super(store, primaryModelClass, {noticia: payload}, id, requestType);
	}
});
