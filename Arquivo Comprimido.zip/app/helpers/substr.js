import Ember from 'ember';

export function substr([value], namedArgs) {
  let str = value;
  let len = namedArgs.size;
  // let start = 0;

  // let out = str.substr(start, len);

  let expString = str.split(/\s+/,len);
  let out = expString.join(" ");

  if (str.length > len) {
  	out += ' [...]';
  }
  
  return Ember.String.htmlSafe(out);
}

export default Ember.Helper.helper(substr);