import Ember from 'ember';

export default Ember.Route.extend({
	model() {
		// console.log('aqui');
		return $.get(`http://localhost/ember-bootstrap-api/tags.php`).then(results => {
			let json = JSON.parse(results);
			let tags = json['tags'];
			return tags.map(tag => {
				return tag;
			});						
		});
	}
});
