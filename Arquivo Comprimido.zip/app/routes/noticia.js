import Ember from 'ember';

export default Ember.Route.extend({
	model(params) {
		let slug = params.slug;
		return $.get(`http://localhost/ember-bootstrap-api/post-slug.php?slug=${slug}`).then(results => {
			let json = JSON.parse(results);
			let post = json['post'];
			return post;				
		});
	}
});