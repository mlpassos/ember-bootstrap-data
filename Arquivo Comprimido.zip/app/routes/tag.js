import Ember from 'ember';

export default Ember.Route.extend({
	slug: '',
	model(params) {
		// console.log('to aqui na tag');
		let slug = params.slug;
		this.set('slug', slug);
		// console.log('aqui', slug);
		return $.get(`http://localhost/ember-bootstrap-api/tag-slug.php?slug=${slug}`).then(results => {
			let json = JSON.parse(results);
			let posts = json['posts'];
			return posts.map(post => {
				return post;
			});						
		});
	},
	setupController(controller) {
		this._super(...arguments);
		controller.set('slug', this.get('slug'));
	},
});