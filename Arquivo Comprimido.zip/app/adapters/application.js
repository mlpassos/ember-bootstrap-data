import DS from 'ember-data';

export default DS.RESTAdapter.extend({
	host: 'http://www.instadev.com.br',
	urlForQuery(query, modelName) {
		switch(modelName) {
			case 'noticias':
				return `${this.get('host')}/ember-bootstrap-api/recent-posts.php`;
			default:
				return this._super(...arguments);
		}
	}
});