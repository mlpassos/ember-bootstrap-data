import { substr } from 'ember-bootstrap/helpers/substr';
import { module, test } from 'qunit';

module('Unit | Helper | substr');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = substr([42]);
  assert.ok(result);
});
